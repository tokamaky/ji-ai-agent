import React from 'react'
import { useNavigate } from 'react-router-dom'
import { clsx } from 'clsx'
import { ArrowRight } from 'lucide-react'

interface Feature {
  icon: string
  text: string
}

interface AppCardProps {
  title: string
  description: string
  features: Feature[]
  to: string
  gradient: string
  icon?: React.ReactNode
  badge?: string
}

export const AppCard = React.memo(function AppCard({
  title,
  description,
  features,
  to,
  gradient,
  icon,
  badge,
}: AppCardProps) {
  const navigate = useNavigate()

  return (
    <button
      onClick={() => navigate(to)}
      className={clsx(
        'relative w-full text-left rounded-2xl p-6',
        'shadow-lg hover:shadow-xl',
        'transform hover:-translate-y-1 active:translate-y-0',
        'transition-all duration-200',
        'focus:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2',
        'overflow-hidden group',
        gradient,
      )}
    >
      {/* Badge */}
      {badge && (
        <span className="absolute top-4 right-4 px-3 py-1 text-xs font-semibold rounded-full bg-white/20 text-white">
          {badge}
        </span>
      )}

      {/* Icon */}
      <div className="w-14 h-14 rounded-xl flex items-center justify-center mb-4 bg-white/20">
        {icon || <span className="text-3xl">✨</span>}
      </div>

      {/* Title */}
      <h2 className="text-2xl font-bold text-white mb-2">
        {title}
      </h2>

      {/* Description */}
      <p className="text-white/85 text-sm mb-4 leading-relaxed">
        {description}
      </p>

      {/* Feature list */}
      <ul className="space-y-2 mb-4">
        {features.map((f, i) => (
          <li key={i} className="flex items-center gap-2 text-white/90 text-sm">
            <span>{f.icon}</span>
            <span>{f.text}</span>
          </li>
        ))}
      </ul>

      {/* CTA */}
      <div className="flex items-center gap-2 text-white font-medium text-sm">
        <span>Get Started</span>
        <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
      </div>
    </button>
  )
})
