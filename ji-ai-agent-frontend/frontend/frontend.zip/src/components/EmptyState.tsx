import React from 'react'
import { clsx } from 'clsx'
import { Bot, Sparkles, Globe, Code2, FileText, BrainCircuit, Heart, MessageCircleHeart, Flower2, Sparkle } from 'lucide-react'
import type { AppType } from '@/types'

interface EmptyStateProps {
  appType: AppType
  onStartChat: () => void
}

/* ── Manus: AI Super Agent ── */
const manusCapabilities = [
  { icon: <Globe size={16} />, label: 'Web Search', desc: 'Search and browse the internet' },
  { icon: <Code2 size={16} />, label: 'Code Execution', desc: 'Run code in terminal' },
  { icon: <FileText size={16} />, label: 'File Operations', desc: 'Read and write files' },
  { icon: <BrainCircuit size={16} />, label: 'Deep Reasoning', desc: 'Multi-step problem solving' },
]

function ManusEmptyState({ onStartChat }: { onStartChat: () => void }) {
  return (
    <div className="relative flex flex-col items-center justify-center h-full w-full overflow-hidden px-4 py-12">
      {/* Animated star field background */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute inset-0 bg-gradient-to-b from-violet-950/40 via-surface-950 to-surface-950" />
        {/* Stars */}
        {Array.from({ length: 40 }).map((_, i) => (
          <div
            key={i}
            className="absolute rounded-full bg-white"
            style={{
              width: `${Math.random() * 2 + 1}px`,
              height: `${Math.random() * 2 + 1}px`,
              top: `${Math.random() * 60}%`,
              left: `${Math.random() * 100}%`,
              opacity: Math.random() * 0.5 + 0.2,
              animation: `twinkle ${2 + Math.random() * 3}s ease-in-out infinite`,
              animationDelay: `${Math.random() * 2}s`,
            }}
          />
        ))}
        {/* Glow orbs */}
        <div className="absolute top-1/4 left-1/4 w-64 h-64 rounded-full bg-violet-600/10 blur-3xl animate-pulse" />
        <div className="absolute bottom-1/3 right-1/4 w-48 h-48 rounded-full bg-purple-600/10 blur-3xl animate-pulse" style={{ animationDelay: '0.5s' }} />
      </div>

      {/* Content */}
      <div className="relative z-10 flex flex-col items-center text-center max-w-lg">
        {/* Avatar */}
        <div className="relative mb-8">
          {/* Orbiting rings */}
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-28 h-28 rounded-full border border-violet-500/20 animate-spin" style={{ animationDuration: '8s' }} />
          </div>
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-36 h-36 rounded-full border border-purple-500/10 animate-spin" style={{ animationDuration: '12s', animationDirection: 'reverse' }} />
          </div>
          {/* Avatar circle */}
          <div className="relative w-24 h-24 rounded-3xl bg-gradient-to-br from-violet-600 via-purple-600 to-indigo-700 flex items-center justify-center shadow-2xl shadow-violet-500/30 animate-float">
            <Bot size={44} className="text-white" />
            {/* Glow pulse */}
            <div className="absolute inset-0 rounded-3xl bg-gradient-to-br from-violet-400/20 to-purple-400/20 animate-pulse" />
            {/* Status indicator */}
            <div className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-emerald-500 border-2 border-surface-950 flex items-center justify-center">
              <div className="w-2 h-2 rounded-full bg-white animate-pulse" />
            </div>
          </div>
        </div>

        {/* Title */}
        <div className="mb-2">
          <h2 className="text-2xl font-bold text-surface-100 mb-1 tracking-tight">
            AI Super Agent
          </h2>
          <p className="text-sm text-violet-400 font-medium">Powered by Advanced Reasoning</p>
        </div>

        {/* Description */}
        <p className="text-surface-400 text-sm leading-relaxed mb-8 max-w-sm">
          I can search the web, execute code, analyze files, and handle complex multi-step tasks.
          Just tell me what you need.
        </p>

        {/* Capability cards */}
        <div className="grid grid-cols-2 gap-3 w-full mb-8">
          {manusCapabilities.map((cap, i) => (
            <div
              key={i}
              className="group flex items-start gap-3 p-3 rounded-2xl bg-white/5 border border-white/5 hover:bg-white/10 hover:border-violet-500/30 transition-all duration-200"
            >
              <div className="flex-shrink-0 w-8 h-8 rounded-xl bg-violet-600/20 flex items-center justify-center text-violet-400 group-hover:bg-violet-600/30 transition-colors">
                {cap.icon}
              </div>
              <div className="text-left">
                <p className="text-xs font-semibold text-surface-200">{cap.label}</p>
                <p className="text-[11px] text-surface-500 mt-0.5">{cap.desc}</p>
              </div>
            </div>
          ))}
        </div>

        {/* CTA */}
        <button
          onClick={onStartChat}
          className={clsx(
            'group relative flex items-center gap-3 px-7 py-3.5 rounded-2xl',
            'bg-gradient-to-r from-violet-600 to-purple-600',
            'hover:from-violet-500 hover:to-purple-500',
            'text-white text-sm font-semibold',
            'shadow-xl shadow-violet-500/25 hover:shadow-violet-500/40',
            'transform hover:-translate-y-0.5 active:translate-y-0',
            'transition-all duration-200',
          )}
        >
          <Sparkles size={16} className="text-violet-200" />
          <span>Start a Mission</span>
          <Sparkles size={14} className="text-violet-200 opacity-0 group-hover:opacity-100 transition-opacity" />
        </button>

        {/* Hint */}
        <p className="mt-4 text-xs text-surface-600">Try: "Search for the latest AI news"</p>
      </div>
    </div>
  )
}

/* ── Love Advisor ── */
const loveTopics = [
  { icon: <Heart size={14} />, text: 'Dating & Relationships' },
  { icon: <MessageCircleHeart size={14} />, text: 'Communication Tips' },
  { icon: <Flower2 size={14} />, text: 'Emotional Well-being' },
  { icon: <Sparkle size={14} />, text: 'Self-Growth & Love' },
]

function LoveEmptyState({ onStartChat }: { onStartChat: () => void }) {
  return (
    <div className="relative flex flex-col items-center justify-center h-full w-full overflow-hidden px-4 py-12">
      {/* Animated background */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute inset-0 bg-gradient-to-b from-pink-950/30 via-rose-950/20 to-surface-950" />
        {/* Floating hearts */}
        {Array.from({ length: 8 }).map((_, i) => (
          <div
            key={i}
            className="absolute text-pink-500/10 animate-float"
            style={{
              top: `${15 + i * 10}%`,
              left: `${5 + (i % 3) * 30}%`,
              animationDuration: `${3 + i * 0.5}s`,
              animationDelay: `${i * 0.3}s`,
              fontSize: `${12 + (i % 3) * 8}px`,
            }}
          >
            <Heart />
          </div>
        ))}
        {/* Warm glow orbs */}
        <div className="absolute top-1/3 left-1/4 w-72 h-72 rounded-full bg-pink-600/10 blur-3xl animate-pulse" />
        <div className="absolute bottom-1/4 right-1/4 w-56 h-56 rounded-full bg-rose-600/10 blur-3xl animate-pulse" style={{ animationDelay: '0.7s' }} />
      </div>

      {/* Content */}
      <div className="relative z-10 flex flex-col items-center text-center max-w-lg">
        {/* Avatar */}
        <div className="relative mb-8">
          {/* Orbiting hearts */}
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-28 h-28 rounded-full border border-pink-500/20 animate-spin" style={{ animationDuration: '10s' }} />
          </div>
          {/* Avatar circle */}
          <div className="relative w-24 h-24 rounded-3xl bg-gradient-to-br from-pink-500 via-rose-500 to-pink-600 flex items-center justify-center shadow-2xl shadow-pink-500/30 animate-float">
            <Heart size={44} className="text-white fill-white/30" />
            {/* Warm glow */}
            <div className="absolute inset-0 rounded-3xl bg-gradient-to-br from-pink-400/20 to-rose-400/20 animate-pulse" />
            {/* Sparkle accent */}
            <div className="absolute -top-2 -right-2 w-7 h-7 rounded-full bg-amber-400 flex items-center justify-center shadow-lg">
              <Sparkle size={14} className="text-amber-800" />
            </div>
          </div>
        </div>

        {/* Title */}
        <div className="mb-2">
          <h2 className="text-2xl font-bold text-surface-100 mb-1 tracking-tight">
            AI Love Advisor
          </h2>
          <p className="text-sm text-pink-400 font-medium">Warm guidance for your heart</p>
        </div>

        {/* Description */}
        <p className="text-surface-400 text-sm leading-relaxed mb-6 max-w-sm">
          Whether it's dating questions, relationship confusion, or emotional challenges —
          I'm here to listen, understand, and help you find clarity.
        </p>

        {/* Topic pills */}
        <div className="flex flex-wrap justify-center gap-2 mb-8">
          {loveTopics.map((topic, i) => (
            <div
              key={i}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-pink-500/10 border border-pink-500/20 text-pink-400 text-xs font-medium"
            >
              <span className="text-pink-300">{topic.icon}</span>
              <span>{topic.text}</span>
            </div>
          ))}
        </div>

        {/* CTA */}
        <button
          onClick={onStartChat}
          className={clsx(
            'group relative flex items-center gap-3 px-7 py-3.5 rounded-2xl',
            'bg-gradient-to-r from-pink-500 to-rose-500',
            'hover:from-pink-400 hover:to-rose-400',
            'text-white text-sm font-semibold',
            'shadow-xl shadow-pink-500/25 hover:shadow-pink-500/40',
            'transform hover:-translate-y-0.5 active:translate-y-0',
            'transition-all duration-200',
          )}
        >
          <Heart size={16} className="text-pink-200 fill-pink-200" />
          <span>Begin Your Journey</span>
          <Heart size={14} className="text-pink-200 fill-pink-200 opacity-0 group-hover:opacity-100 transition-opacity" />
        </button>

        {/* Hint */}
        <p className="mt-4 text-xs text-surface-600">Try: "I'm confused about my relationship..."</p>
      </div>
    </div>
  )
}

/* ── EmptyState export ── */
export const EmptyState = React.memo(function EmptyState({ appType, onStartChat }: EmptyStateProps) {
  if (appType === 'love_app') {
    return <LoveEmptyState onStartChat={onStartChat} />
  }
  return <ManusEmptyState onStartChat={onStartChat} />
})
