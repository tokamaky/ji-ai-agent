import React from 'react'
import ReactMarkdown from 'react-markdown'
import remarkGfm from 'remark-gfm'
import rehypeRaw from 'rehype-raw'
import { CodeBlock } from './CodeBlock'

interface MarkdownProps {
  content: string
  className?: string
}

/** Markdown 渲染组件，支持 GFM、代码高亮、原始 HTML */
export const Markdown = React.memo(function Markdown({ content, className }: MarkdownProps) {
  return (
    <ReactMarkdown
      className={className}
      remarkPlugins={[remarkGfm]}
      rehypePlugins={[rehypeRaw]}
      components={{
        // 代码块
        code({ className: cls, children, ...props }) {
          const match = /language-(\w+)/.exec(cls ?? '')
          const codeStr = String(children).replace(/\n$/, '')
          const isBlock = codeStr.includes('\n') || match

          if (isBlock) {
            return <CodeBlock language={match?.[1]}>{codeStr}</CodeBlock>
          }
          return (
            <code
              className="px-1.5 py-0.5 rounded text-sm font-mono
                bg-gray-100 dark:bg-gray-700 text-pink-600 dark:text-pink-400"
              {...props}
            >
              {children}
            </code>
          )
        },

        // 链接：在新标签打开
        a({ href, children }) {
          return (
            <a
              href={href}
              target="_blank"
              rel="noopener noreferrer"
              className="text-primary hover:underline"
            >
              {children}
            </a>
          )
        },

        // 表格样式
        table({ children }) {
          return (
            <div className="overflow-x-auto my-3">
              <table className="min-w-full border-collapse text-sm">{children}</table>
            </div>
          )
        },
        th({ children }) {
          return (
            <th className="border border-gray-300 dark:border-gray-600 px-3 py-2 bg-gray-50 dark:bg-gray-800 font-semibold text-left">
              {children}
            </th>
          )
        },
        td({ children }) {
          return (
            <td className="border border-gray-300 dark:border-gray-600 px-3 py-2">{children}</td>
          )
        },

        // 引用块
        blockquote({ children }) {
          return (
            <blockquote className="border-l-4 border-primary/50 pl-4 my-3 text-gray-600 dark:text-gray-400 italic">
              {children}
            </blockquote>
          )
        },
      }}
    >
      {content}
    </ReactMarkdown>
  )
})
