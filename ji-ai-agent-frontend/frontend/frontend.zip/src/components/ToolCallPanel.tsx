import React, { useState } from 'react'
import { clsx } from 'clsx'
import { ChevronDown, ChevronRight, Wrench, CheckCircle, XCircle, Loader2 } from 'lucide-react'
import type { ToolCallInfo } from '@/types'

const STATUS_ICON: Record<string, React.ReactNode> = {
  pending: <Loader2 size={13} className="text-gray-400 animate-spin" />,
  running: <Loader2 size={13} className="text-blue-500 animate-spin" />,
  completed: <CheckCircle size={13} className="text-green-500" />,
  failed: <XCircle size={13} className="text-red-500" />,
}

const STATUS_LABEL: Record<string, string> = {
  pending: 'Queued',
  running: 'Running',
  completed: 'Done',
  failed: 'Failed',
}

interface ToolCallItemProps {
  toolCall: ToolCallInfo
}

const ToolCallItem = React.memo(function ToolCallItem({ toolCall }: ToolCallItemProps) {
  const [expanded, setExpanded] = useState(false)

  return (
    <div className="border border-gray-200 dark:border-gray-600 rounded-lg overflow-hidden text-xs">
      <button
        onClick={() => setExpanded((v) => !v)}
        className={clsx(
          'w-full flex items-center gap-2 px-3 py-2 text-left',
          'bg-gray-50 dark:bg-gray-800/60 hover:bg-gray-100 dark:hover:bg-gray-700/50',
          'transition-colors',
        )}
      >
        <Wrench size={12} className="text-gray-500 flex-shrink-0" />
        <span className="font-mono font-medium text-gray-700 dark:text-gray-200 flex-1 truncate">
          {toolCall.toolName}
        </span>
        <span className="flex items-center gap-1 text-gray-500 dark:text-gray-400">
          {STATUS_ICON[toolCall.status]}
          <span className="hidden sm:inline">{STATUS_LABEL[toolCall.status]}</span>
        </span>
        {expanded ? (
          <ChevronDown size={13} className="flex-shrink-0 text-gray-400" />
        ) : (
          <ChevronRight size={13} className="flex-shrink-0 text-gray-400" />
        )}
      </button>

      {expanded && (
        <div className="px-3 py-2 space-y-2 bg-white dark:bg-gray-900">
          {toolCall.arguments && Object.keys(toolCall.arguments).length > 0 && (
            <div>
              <p className="text-gray-400 uppercase text-[10px] tracking-wide mb-1">Arguments</p>
              <pre className="text-gray-700 dark:text-gray-300 text-[11px] overflow-x-auto whitespace-pre-wrap">
                {JSON.stringify(toolCall.arguments, null, 2)}
              </pre>
            </div>
          )}
          {toolCall.result && (
            <div>
              <p className="text-gray-400 uppercase text-[10px] tracking-wide mb-1">Result</p>
              <p className="text-gray-700 dark:text-gray-300 text-[11px] whitespace-pre-wrap line-clamp-6">
                {toolCall.result}
              </p>
            </div>
          )}
        </div>
      )}
    </div>
  )
})

interface ToolCallPanelProps {
  toolCalls: ToolCallInfo[]
}

export const ToolCallPanel = React.memo(function ToolCallPanel({ toolCalls }: ToolCallPanelProps) {
  if (toolCalls.length === 0) return null

  return (
    <div className="w-full max-w-md space-y-1.5 mb-1">
      {toolCalls.map((tc) => (
        <ToolCallItem key={tc.id} toolCall={tc} />
      ))}
    </div>
  )
})
