import { TopBar } from '@/components/TopBar'
import { AppCard } from '@/components/AppCard'
import { Sparkles, Heart, Bot, ArrowRight, Star, Zap } from 'lucide-react'

const loveFeatures = [
  { icon: '💬', text: 'Multi-turn conversation with memory' },
  { icon: '⚡', text: 'Real-time SSE streaming replies' },
  { icon: '💾', text: 'Session history persisted locally' },
  { icon: '📱', text: 'Responsive mobile-friendly design' },
]

const manusFeatures = [
  { icon: '🔧', text: 'Live tool-call visualization' },
  { icon: '🌐', text: 'Web search & code execution' },
  { icon: '📝', text: 'Markdown + syntax highlighting' },
  { icon: '🤔', text: 'Thinking process shown in real time' },
]

export default function HomePage() {
  return (
    <div className="flex flex-col min-h-screen bg-surface-950">
      <TopBar />

      <main className="flex-1 flex flex-col items-center justify-center px-6 py-16">
        {/* Hero Section */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          {/* Logo */}
          <div className="flex items-center justify-center gap-3 mb-8">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-violet-600 to-purple-600 flex items-center justify-center shadow-2xl shadow-violet-500/30">
              <Sparkles size={28} className="text-white" />
            </div>
          </div>

          {/* Title */}
          <h1 className="text-5xl sm:text-6xl font-bold mb-6 text-surface-100">
            JI AI Agent
          </h1>

          {/* Subtitle */}
          <p className="text-lg sm:text-xl text-surface-400 max-w-xl mx-auto mb-8 leading-relaxed">
            Not a cold tool, but a partner who understands you.
            <br />
            Whether it is relationship confusion or complex work tasks, I am here for you.
          </p>
        </div>

        {/* App Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 w-full max-w-4xl mb-12">
          <AppCard
            title="Love Advisor"
            description="When relationships confuse you, I am willing to listen, understand, and accompany you. With professional psychological knowledge and warm conversation, I help you see your heart clearly."
            features={loveFeatures}
            to="/love"
            gradient="bg-gradient-to-br from-pink-500 via-pink-500 to-rose-500"
            icon={<Heart size={26} className="text-white" />}
            badge="Warm Company"
          />
          <AppCard
            title="AI Super Agent"
            description="Not a simple Q&A machine. I can call tools, search information, write code — helping you efficiently complete complex tasks and workflows."
            features={manusFeatures}
            to="/manus"
            gradient="bg-gradient-to-br from-violet-600 via-violet-500 to-purple-600"
            icon={<Bot size={26} className="text-white" />}
            badge="Enhanced"
          />
        </div>

        {/* Features */}
        <div className="flex flex-wrap justify-center gap-3">
          <div className="flex items-center gap-2 px-4 py-2 rounded-xl bg-surface-900 border border-surface-700 text-surface-400">
            <Star size={16} className="text-amber-500" />
            <span className="text-sm">Genuine</span>
          </div>
          <div className="flex items-center gap-2 px-4 py-2 rounded-xl bg-surface-900 border border-surface-700 text-surface-400">
            <Zap size={16} className="text-violet-500" />
            <span className="text-sm">Streaming</span>
          </div>
          <div className="flex items-center gap-2 px-4 py-2 rounded-xl bg-surface-900 border border-surface-700 text-surface-400">
            <Heart size={16} className="text-pink-500" />
            <span className="text-sm">Understanding</span>
          </div>
          <div className="flex items-center gap-2 px-4 py-2 rounded-xl bg-surface-900 border border-surface-700 text-surface-400">
            <Bot size={16} className="text-violet-500" />
            <span className="text-sm">Deep Thinking</span>
          </div>
        </div>

        {/* CTA */}
        <div className="mt-12 text-center">
          <p className="text-sm text-surface-600 mb-2">
            Ready to start exploring?
          </p>
          <div className="flex items-center justify-center gap-2 text-sm text-surface-500">
            <span>Choose one to begin</span>
            <ArrowRight size={14} />
          </div>
        </div>
      </main>

      <footer className="text-center py-6 text-sm text-surface-700">
        JI AI Agent © {new Date().getFullYear()}
      </footer>
    </div>
  )
}
