import type { SSEConfig } from '@/types/api'
import type { SSEStatus } from '@/types/sse'

/**
 * SSEManager — wraps EventSource with automatic reconnection and lifecycle management.
 *
 * Usage:
 *   const mgr = new SSEManager(config)
 *   mgr.connect()
 *   // when done:
 *   mgr.close()
 */

type ResolvedConfig = Omit<Required<SSEConfig>, 'params'> & {
  params: Record<string, string> | undefined
}

export class SSEManager {
  private eventSource: EventSource | null = null
  private config: ResolvedConfig
  private retryCount = 0
  private retryTimer: ReturnType<typeof setTimeout> | null = null
  private _status: SSEStatus = 'idle'
  private onStatusChange?: (status: SSEStatus) => void
  /** Indicates that the stream has delivered at least one message, so an
   *  end-of-stream should be treated as normal completion rather than a
   *  network error worth retrying. */
  private receivedData = false
  /** Prevents multiple close() calls from triggering duplicate onClose callbacks */
  private isClosing = false
  /** If true, will NOT attempt to reconnect on error */
  private noReconnect = false

  constructor(config: SSEConfig, onStatusChange?: (status: SSEStatus) => void) {
    this.config = {
      maxRetries: 3,
      retryInterval: 1500,
      onError: () => {},
      onOpen: () => {},
      onClose: () => {},
      params: undefined,
      ...config,
    }
    this.onStatusChange = onStatusChange
  }

  get status(): SSEStatus {
    return this._status
  }

  private setStatus(s: SSEStatus) {
    this._status = s
    this.onStatusChange?.(s)
  }

  private buildUrl(): string {
    const { url, params } = this.config
    if (!params || Object.keys(params).length === 0) return url
    const search = new URLSearchParams(params).toString()
    return `${url}?${search}`
  }

  connect(): void {
    this.close()
    this.receivedData = false
    this.noReconnect = false
    this.setStatus('connecting')

    const source = new EventSource(this.buildUrl())
    this.eventSource = source

    source.onopen = () => {
      this.retryCount = 0
      this.setStatus('connected')
      this.config.onOpen()
    }

    source.onmessage = (event: MessageEvent<string>) => {
      this.receivedData = true
      this.config.onMessage(event.data)
    }

    source.onerror = () => {
      // If no reconnect flag is set, don't retry
      if (this.noReconnect || this.isClosing) {
        if (!this.isClosing) {
          this.close()
        }
        return
      }

      // If we received data, this is likely normal completion (SSE stream ended)
      if (this.receivedData) {
        this.close()
        return
      }

      // Genuine connection error before any data arrived
      this.setStatus('error')
      this.config.onError(new Event('error'))

      // DON'T retry automatically - just close
      this.close()
      this.config.onClose()
    }
    
    // Prevent EventSource's built-in automatic reconnection
    source.onclose = () => {
      // Mark as closing to prevent auto-reconnect
      this.isClosing = true
      this.noReconnect = true
      if (!this.receivedData) {
        // If no data was received, call onError
        this.setStatus('error')
        this.config.onError(new Event('error'))
      }
      this.config.onClose()
    }
  }

  close(): void {
    if (this.isClosing) return
    this.isClosing = true

    if (this.retryTimer) {
      clearTimeout(this.retryTimer)
      this.retryTimer = null
    }
    if (this.eventSource) {
      this.eventSource.close()
      this.eventSource = null
    }
    if (this._status !== 'closed') {
      this.setStatus('closed')
    }
    this.config.onClose()
  }
}

/** Fetch-based SSE reader for scenarios requiring POST or custom headers */
export async function fetchSSE(
    url: string,
    onChunk: (chunk: string) => void,
    onDone: () => void,
    signal?: AbortSignal,
): Promise<void> {
  const response = await fetch(url, { signal })
  if (!response.body) {
    onDone()
    return
  }

  const reader = response.body.getReader()
  const decoder = new TextDecoder()

  try {
    while (true) {
      const { done, value } = await reader.read()
      if (done) break
      const text = decoder.decode(value, { stream: true })
      for (const line of text.split('\n')) {
        if (line.startsWith('data: ')) {
          onChunk(line.slice(6))
        }
      }
    }
  } finally {
    reader.releaseLock()
    onDone()
  }
}